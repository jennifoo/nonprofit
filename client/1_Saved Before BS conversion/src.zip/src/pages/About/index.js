import React from "react";

function About() {
return (
        <>
        <main id="about" className="container">

        </main>
        </>
)
}

export default About;