import React from "react";

function Blog() {
return (
        <>
        <main id="about" className="container">

        </main>
        </>
)
}

export default Blog;