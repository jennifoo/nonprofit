import React from "react";
import { BrowserRouter as Router, Link } from "react-router-dom";
import Nav from 'react-bootstrap/Nav';
import Col from 'react-bootstrap/Col';


function Nav() {
  return(
    <nav className="navbar navbar-expand-lg navbar-light bg-light">
      <Link to="/portfolio" className="navbar-brand"><img src={require("../../images/brand/free-the-captives-logo.png")} alt="logotype - free the captives logo" height="57px" /></Link>
      <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span className="navbar-toggler-icon"></span>
      </button>
      <div className="collapse navbar-collapse" id="navbarNav">
        <ul className="navbar-nav">
          <li className="nav-item"> {/* dropdown */}
            <Link to="/about" className="nav-link" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">About</Link> {/*class: dropdown-toggle*/}
          </li>
          <li className="nav-item">
            <Link to="/blog" className="nav-link">Blog</Link>
          </li>
        </ul>
      </div>
    </nav>
  )
}

export default Nav;